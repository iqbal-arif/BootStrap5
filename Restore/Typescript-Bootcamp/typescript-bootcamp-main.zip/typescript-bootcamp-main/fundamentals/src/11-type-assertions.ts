

const input =
    document.getElementById("input-field")  as HTMLInputElement;

input.value;

