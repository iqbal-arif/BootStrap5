


let uniqueIdentifier: number | string = 1000;

uniqueIdentifier = "201e72bb-49e3-40ef-8331-b7f3e7d947f8";

const keys: (number | string) [] = [1000, "Hello"];

let courseId: number | null = 1000;

courseId = null;


