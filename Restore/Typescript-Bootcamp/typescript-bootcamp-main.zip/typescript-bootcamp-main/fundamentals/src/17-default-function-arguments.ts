




function printCourse(title = "TITLE", subtitle = "SUBTITLE", lessonsCount = 0) {

    console.log(`Title: ${title}, Subtitle: ${subtitle} lessons count: ${lessonsCount}`);

}

printCourse(
    "Typescript Bootcamp",
    "Learn the language fundamentals, build practical projects",
    10);

printCourse(
    "Typescript Bootcamp",
    "Learn the language fundamentals, build practical projects"
);

printCourse();
