
const express = require('express');

import {Request,Response} from "express";

let req : Request;


