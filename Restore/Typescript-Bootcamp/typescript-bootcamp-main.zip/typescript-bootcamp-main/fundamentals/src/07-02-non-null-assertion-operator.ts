

let courseId : number | null;

courseId!.toString();


