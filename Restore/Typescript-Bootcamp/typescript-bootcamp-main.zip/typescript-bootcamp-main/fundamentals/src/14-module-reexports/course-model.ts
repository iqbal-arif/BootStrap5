

export type Course = {
    readonly title:string,
    subtitle:string,
    lessonsCount?:number
};
