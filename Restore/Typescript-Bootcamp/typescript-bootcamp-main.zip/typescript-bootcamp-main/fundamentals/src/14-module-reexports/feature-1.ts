

export function loadAllCourses() {

}




