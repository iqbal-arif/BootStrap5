
import {Course} from "./course-model";
import {loadAllCourses} from "./feature-1";
import {saveCourse} from "./feature-2";

export {
    Course,
    loadAllCourses,
    saveCourse
};
