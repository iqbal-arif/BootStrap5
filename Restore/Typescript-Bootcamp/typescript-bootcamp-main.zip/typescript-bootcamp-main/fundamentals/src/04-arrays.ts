
// array
const numbers = [1, 2 ,3];

numbers.push(4);

// numbers.push("Hello World");
