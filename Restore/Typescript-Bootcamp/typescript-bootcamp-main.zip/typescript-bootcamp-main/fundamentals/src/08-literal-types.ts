


const title = "Typescript Bootcamp";

const lessonsCount = 10;

let pageSize: 10 | 15 | 20 = 10;

let courseStatus: "draft" | "published" | "unpublished" |
    "archived" = "draft";

courseStatus = "published";
