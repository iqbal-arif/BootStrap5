
let lessonsCount:any = 10;

let numbers : any[] = [10, 20, "Hello", true];

printCourse( "Typescript Bootcamp", 10);

function printCourse(title:string, lessonsCount:number) {

    console.log(`Title: ${title}, lessons count: ${lessonsCount}`);

}
