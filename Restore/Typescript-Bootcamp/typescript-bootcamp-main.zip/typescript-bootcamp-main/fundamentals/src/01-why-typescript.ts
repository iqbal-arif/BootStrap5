
const courseName = "Typescript Bootcamp";

debugger;

//comment

if (courseName) {

    const subtitle = "Learn the language fundamentals, build practical projects";

    printCourseName(courseName);
}

function printCourseName(name :string) {

    debugger;

    console.log("The course name is " + name.toUpperCase());

}
