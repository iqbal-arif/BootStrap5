

document.addEventListener('click', () =>{

    console.log(`The button was clicked`);

});
